import pandas as pd
import requests
from price_handle_utils import compute_final_price
from brand_utils import infer_brand
from os_utils import process_os
from ram_utils import process_ram
from rom_utils import process_rom
from battery_utils import process_battery
from camera_utils import process_camera
from chipset_utils import process_chipset
from gpu_utils import process_gpu
from display_size_utils import process_display
from screen_utils import process_screen
from sensor_utils import process_sensor
from nfc_utils import process_nfc_column
from jack_support_utils import process_jack_support
from numeric_utils import clean_numeric_column
from normalize import normalize_for_saving

from elastic_utils import upload_to_elasticsearch

from normalize import normalize_for_saving

import sys, os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# -------------------------------------------------------
# 🔗 Elasticsearch Config
# -------------------------------------------------------
ES_URL = "https://e72eb8c5112142169a3526c1c5f70827.us-central1.gcp.cloud.es.io:443"
ES_API_KEY = "MDlXWlBab0I4RHFXM24wdHlrRWQ6bUxQRlBheFZwNHBEZUFqM1RGWldRdw=="
INDEX_NAME = "processed_products"

HEADERS = {
    "Content-Type": "application/json",
    "Authorization": f"ApiKey {ES_API_KEY}"
}

# -------------------------------------------------------
# 🔽 LẤY DỮ LIỆU TỪ RAWDATA (file CSV hoặc parquet)
# -------------------------------------------------------
RAW_PATH = os.path.join(os.path.dirname(__file__), "..", "RawData", "raw_output.csv")

if not os.path.exists(RAW_PATH):
    print(f"❌ Không tìm thấy file dữ liệu raw tại: {RAW_PATH}")
    sys.exit(1)

df_track = pd.read_csv(RAW_PATH)
if df_track.empty:
    print("🟢 Không có dữ liệu mới để xử lý.")
    sys.exit(0)

print(f"🟢 Đọc {len(df_track)} bản ghi từ raw_output.csv")
print(df_track.columns.tolist())

# -------------------------------------------------------
# 🧮 XỬ LÝ GIÁ
# -------------------------------------------------------
df_track = compute_final_price(df_track)

# -------------------------------------------------------
# 🧠 CHUẨN HÓA CÁC CỘT
# -------------------------------------------------------
df_track["manufacturer"] = df_track.apply(infer_brand, axis=1)
df_track = process_os(df_track)
df_track = process_ram(df_track)
df_track = process_rom(df_track)
df_track = process_battery(df_track)
df_track = process_camera(df_track)
df_track = process_chipset(df_track)
df_track = process_gpu(df_track)
df_track = process_display(df_track)
df_track = process_screen(df_track)
df_track = process_sensor(df_track)
df_track = process_nfc_column(df_track)
df_track = process_jack_support(df_track)

# -------------------------------------------------------
# 🔢 CHUẨN HÓA DỮ LIỆU SỐ
# -------------------------------------------------------
df_track = clean_numeric_column(df_track, ["ram", "storage", "battery", "watt", "price"])

# -------------------------------------------------------
# 🧾 CHUẨN HÓA DỮ LIỆU TRƯỚC KHI LƯU
# -------------------------------------------------------
df_saving = normalize_for_saving(df_track)

print("Tổng dòng trong df_saving:", len(df_saving))
print("Số product_id duy nhất:", df_saving["product_id"].nunique())

# -------------------------------------------------------
# 📤 ĐẨY LÊN ELASTICSEARCH
# -------------------------------------------------------
def push_to_elasticsearch(df, index_name):
    success, failed = 0, 0
    for i, row in df.iterrows():
        doc = row.to_dict()
        doc_id = str(doc.get("product_id", i))

        try:
            res = requests.put(
                f"{ES_URL}/{index_name}/_doc/{doc_id}",
                headers=HEADERS,
                json=doc,
                timeout=10
            )
            if res.status_code in [200, 201]:
                success += 1
            else:
                failed += 1
                print(f"⚠️ Lỗi upload {doc_id}: {res.status_code} - {res.text[:120]}")
        except Exception as e:
            failed += 1
            print(f"❌ Exception khi upload {doc_id}: {e}")

    print(f"\n📊 Kết quả upload:")
    print(f"   ✅ Thành công: {success}")
    print(f"   ❌ Thất bại: {failed}")


print(f"📤 Đang upload {len(df_saving)} bản ghi lên Elasticsearch...")
push_to_elasticsearch(df_saving, INDEX_NAME)
print("\n🎯 Hoàn tất pipeline! Dữ liệu đã được đẩy lên Elasticsearch Cloud.")
