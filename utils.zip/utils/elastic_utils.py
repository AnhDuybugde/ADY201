from elasticsearch import Elasticsearch, helpers
import pandas as pd

# ------------------------------------------------------------
# 🔌 Kết nối Elasticsearch Cloud
# ------------------------------------------------------------
def get_es_client():
    """
    Tạo kết nối đến Elasticsearch Cloud qua API Key.
    """
    es = Elasticsearch(
        "https://e72eb8c5112142169a3526c1c5f70827.us-central1.gcp.cloud.es.io:443",
        api_key="MDlXWlBab0I4RHFXM24wdHlrRWQ6bUxQRlBheFZwNHBEZUFqM1RGWldRdw==",
        verify_certs=True,
        request_timeout=60
    )
    if not es.ping():
        raise ConnectionError("❌ Không thể kết nối Elasticsearch Cloud!")
    print("🔗 Đã kết nối Elasticsearch Cloud thành công.")
    return es


# ------------------------------------------------------------
# 📤 Upload DataFrame lên Elasticsearch
# ------------------------------------------------------------
def upload_to_elasticsearch(es, df: pd.DataFrame, index_name: str):
    """
    Upload toàn bộ DataFrame lên Elasticsearch index chỉ định.
    """
    if df.empty:
        print("⚠️ DataFrame rỗng, không có gì để upload.")
        return

    actions = []
    for _, row in df.iterrows():
        actions.append({
            "_index": index_name,
            "_id": row.get("product_id", None),
            "_source": row.to_dict()
        })

    helpers.bulk(es, actions)
    es.indices.refresh(index=index_name)
    print(f"✅ Đã upload {len(df)} tài liệu lên index '{index_name}'.")


# ------------------------------------------------------------
# 📥 Lấy dữ liệu từ Elasticsearch về DataFrame
# ------------------------------------------------------------
def fetch_from_elasticsearch(es, index_name: str, size: int = 10000) -> pd.DataFrame:
    """
    Lấy dữ liệu từ Elasticsearch index về dạng pandas DataFrame.
    """
    query = {"query": {"match_all": {}}}
    resp = es.search(index=index_name, body=query, size=size)

    hits = resp.get("hits", {}).get("hits", [])
    if not hits:
        print(f"⚠️ Không có dữ liệu trong index '{index_name}'.")
        return pd.DataFrame()

    df = pd.DataFrame([h["_source"] for h in hits])
    print(f"📦 Đã tải {len(df)} bản ghi từ index '{index_name}'.")
    return df
