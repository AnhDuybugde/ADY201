import requests
import pyodbc
import json
from datetime import datetime

# ------------------------------------------------------------
# ⚙️ CẤU HÌNH KẾT NỐI SQL SERVER
# ------------------------------------------------------------
server = r'localhost\SQLEXPRESS'
database = 'blackmen_restore'
table_name = "phones_track"

# ------------------------------------------------------------
# 🔗 API Cellphones
# ------------------------------------------------------------
url = "https://api.cellphones.com.vn/v2/graphql/query"
headers = {"Content-Type": "application/json", "User-Agent": "Mozilla/5.0"}

province_id = 10
max_pages = 5
category_id = "3"

# ------------------------------------------------------------
# 🧱 KẾT NỐI SQL SERVER
# ------------------------------------------------------------
conn_str = f"Driver={{SQL Server}};Server={server};Database={database};Trusted_Connection=yes;"
conn = pyodbc.connect(conn_str)
cursor = conn.cursor()

# ------------------------------------------------------------
# 🧾 TẠO BẢNG (CÓ THÊM CỘT YEAR THAY CHO VISIBILITY)
# ------------------------------------------------------------
create_table_query = f"""
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='{table_name}' AND xtype='U')
CREATE TABLE {table_name} (
    product_id NVARCHAR(50),
    name NVARCHAR(255),
    manufacturer NVARCHAR(100),
    price FLOAT,
    special_price FLOAT,
    battery NVARCHAR(255),
    camera_primary NVARCHAR(MAX),
    camera_secondary NVARCHAR(MAX),
    chipset NVARCHAR(255),
    display_size NVARCHAR(100),
    gpu NVARCHAR(255),
    memory_internal NVARCHAR(255),
    mobile_display_features NVARCHAR(MAX),
    mobile_type_of_display NVARCHAR(255),
    storage NVARCHAR(255),
    release_date DATETIME NULL,
    year INT NULL,
    nfc NVARCHAR(50),
    jack_support NVARCHAR(50),  
    OS NVARCHAR(255),
    wifi NVARCHAR(255),
    location NVARCHAR(255),
    sensor NVARCHAR(MAX),
    watt NVARCHAR(MAX),
    processed BIT NULL DEFAULT 0
)
"""
cursor.execute(create_table_query)
conn.commit()
print(f"✅ Bảng '{table_name}' đã sẵn sàng (đã thêm cột year thay cho visibility).")

# ------------------------------------------------------------
# 🔁 CÀO DỮ LIỆU
# ------------------------------------------------------------
all_products = []

for page in range(1, max_pages + 1):
    print(f"\n📦 Đang lấy trang {page}...")

    payload = {
        "query": f"""
        query GetProductsByCateId($page: Int, $size: Int){{
            products(
                filter: {{
                    static: {{
                        categories: ["{category_id}"],
                        province_id: {province_id},
                        stock: {{from: 0}}
                    }}
                }},
                page: $page,
                size: $size,
                sort: [{{view: desc}}]
            ){{
                general{{
                    product_id
                    name
                    manufacturer
                    attributes
                }}
                filterable{{
                    price
                    special_price
                }}
            }}
        }}
        """,
        "variables": {"page": page, "size": 50}
    }

    res = requests.post(url, headers=headers, json=payload)
    if res.status_code != 200:
        print(f"❌ HTTP Error {res.status_code}")
        break

    data = res.json()
    products = data.get("data", {}).get("products", [])
    if not products:
        print(f"⚠️ Hết dữ liệu ở trang {page}.")
        break

    all_products.extend(products)
    print(f"✅ Lấy xong {len(products)} sản phẩm (tổng {len(all_products)})")

# ------------------------------------------------------------
# 💾 GHI DỮ LIỆU VÀO SQL SERVER
# ------------------------------------------------------------
insert_query = f"""
INSERT INTO {table_name} (
    product_id, name, manufacturer, price, special_price,
    battery, camera_primary, camera_secondary, chipset,
    display_size, gpu, memory_internal, mobile_display_features,
    mobile_type_of_display, storage, release_date, year,
    nfc, jack_support, OS, wifi, location, sensor, watt, processed
)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
"""

print("\n🚀 Đang ghi dữ liệu vào SQL Server...")

for p in all_products:
    general = p.get("general", {})
    filterable = p.get("filterable", {})

    attrs_raw = general.get("attributes")
    attrs = {}
    if isinstance(attrs_raw, str):
        try:
            attrs = json.loads(attrs_raw)
        except:
            pass
    elif isinstance(attrs_raw, dict):
        attrs = attrs_raw

    def pick(*keys):
        for k in keys:
            if k in attrs:
                return attrs[k]
        return None

    # 🧩 Xử lý hệ điều hành
    os_name = pick("operating_system", "mobile_os_filter")
    os_version = pick("os_version")
    os_value = f"{os_name} {os_version}".strip() if os_name else os_version

    # 🕓 Xử lý ngày và năm phát hành
    release_raw = pick("release_date", "visibility_date", "ra_mat", "ngay_ra_mat")
    release_date = None
    year = None
    if release_raw:
        try:
            release_date = datetime.strptime(release_raw[:10], "%Y-%m-%d")
            year = release_date.year
        except:
            try:
                # Nếu chỉ có năm
                year = int(release_raw.strip()[:4])
            except:
                year = None

    cursor.execute(insert_query, (
        general.get("product_id"),
        general.get("name"),
        general.get("manufacturer"),
        filterable.get("price"),
        filterable.get("special_price"),
        pick("battery", "pin"),
        pick("camera_primary", "camera", "camera_chinh"),
        pick("camera_secondary", "camera_phu", "camera_truoc"),
        pick("chipset", "cpu", "chip"),
        pick("display_size", "man_hinh", "screen_size"),
        pick("gpu"),
        pick("memory_internal", "ram"),
        pick("mobile_display_features", "display_features"),
        pick("mobile_type_of_display", "display_type"),
        pick("storage", "rom", "bo_nho_trong"),
        release_date,
        year,
        pick("mobile_nfc", "nfc"),
        pick("mobile_jack_tai_nghe", "jack_support", "jack_3.5mm"),
        os_value,
        pick("wlan", "wifi"),
        str(province_id),
        pick("mobile_cam_bien", "sensor"),
        pick("mobile_cong_nghe_sac", "sac", "watt"),
        0
    ))

conn.commit()
conn.close()

print(f"🎉 Hoàn tất! Đã lưu {len(all_products)} sản phẩm vào bảng '{table_name}'.")
