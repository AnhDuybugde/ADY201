import pyodbc
import pandas as pd

# ======================================================
# ⚙️ KẾT NỐI SQL SERVER
# ======================================================
server = r'localhost\SQLEXPRESS'
database = 'blackmen_restore'
track_table = "phones_track"
saving_table = "Phones_Saving"

conn = pyodbc.connect(
    f'DRIVER={{ODBC Driver 18 for SQL Server}};'
    f'SERVER={server};DATABASE={database};'
    f'Trusted_Connection=yes;Encrypt=no;'
)
cursor = conn.cursor()

# ======================================================
# 🧱 TẠO BẢNG CHUẨN
# ======================================================
create_table_query = f"""
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='{saving_table}' AND xtype='U')
CREATE TABLE {saving_table} (
    product_id NVARCHAR(50) PRIMARY KEY,
    name NVARCHAR(255),
    brand NVARCHAR(100),
    os NVARCHAR(MAX),
    ram NVARCHAR(100),
    rom NVARCHAR(100),
    battery NVARCHAR(MAX),
    camera_primary NVARCHAR(MAX),
    camera_secondary NVARCHAR(MAX),
    chipset NVARCHAR(100),
    gpu NVARCHAR(100),
    wifi NVARCHAR(MAX),
    location NVARCHAR(100),
    display_size NVARCHAR(50),
    screen NVARCHAR(MAX),
    sensor NVARCHAR(MAX),
    watt NVARCHAR(MAX),
    nfc NVARCHAR(50),
    year INT,
    jack_support NVARCHAR(50),
    price FLOAT
)
"""
cursor.execute(create_table_query)
conn.commit()
print(f"✅ Bảng '{saving_table}' đã sẵn sàng.")

# ======================================================
# 🧾 LẤY DỮ LIỆU TRACK
# ======================================================
df_track = pd.read_sql(f"""
    SELECT * FROM {track_table}
    WHERE processed = 0 OR processed IS NULL
""", conn)

if df_track.empty:
    print("🟢 Không có dữ liệu mới để xử lý.")
    cursor.close()
    conn.close()
    exit()

print(f"🟢 Dữ liệu mới: {len(df_track)} bản ghi")

# ======================================================
# 🔧 HÀM CHỌN GIÁ TRỊ
# ======================================================
def pick(row, *keys):
    for k in keys:
        if k in row and pd.notna(row[k]):
            return row[k]
    return None

# ======================================================
# 💼 CHUẨN HÓA BRAND
# ======================================================
brand_map = {
    "samsung": "Samsung", "galaxy": "Samsung",
    "xiaomi": "Xiaomi", "oppo": "Oppo", "vivo": "Vivo", "realme": "Realme",
    "huawei": "Huawei", "oneplus": "OnePlus", "google": "Google", "sony": "Sony",
    "cubot": "Cubot", "htc": "HTC", "lenovo": "Lenovo", "t-mobile": "T-Mobile",
    "tecno": "Tecno", "walton": "Walton", "infinix": "Infinix", "honor": "Honor",
    "motorola": "Motorola", "nokia": "Nokia", "zte": "ZTE", "tcl": "TCL",
    "meizu": "Meizu", "doogee": "Doogee", "nubia": "Nubia", "nothingphone": "NothingPhone",
    "itel": "Itel", "masstel": "Masstel", "viettel": "Viettel", "tesla": "Tesla"
}

def infer_brand(row):
    brand_lower = str(row["manufacturer"]).lower()
    if brand_lower == "hãng khác":
        name_lower = str(row["name"]).lower()
        for keyword, brand in brand_map.items():
            if keyword in name_lower:
                return brand
    return row["manufacturer"]

# Áp dụng brand
df_track["manufacturer"] = df_track.apply(infer_brand, axis=1)

# Lưu lại brand vào track
for _, row in df_track.iterrows():
    cursor.execute("""
        UPDATE phones_track
        SET manufacturer = ?
        WHERE product_id = ?
    """, row["manufacturer"], row["product_id"])
conn.commit()
print("✅ Brand đã được chuẩn hóa và cập nhật vào bảng track.")

# ======================================================
# 🧩 TẠO DATAFRAME CHUẨN HÓA
# ======================================================
df_saving = pd.DataFrame({
    "product_id": df_track["product_id"],
    "name": [pick(r, "name") for _, r in df_track.iterrows()],
    "brand": [pick(r, "manufacturer", "brand") for _, r in df_track.iterrows()],
    "os": [pick(r, "os", "OS") for _, r in df_track.iterrows()],
    "ram": [pick(r, "memory_internal", "ram", "RAM") for _, r in df_track.iterrows()],
    "rom": [pick(r, "rom", "ROM", "storage") for _, r in df_track.iterrows()],
    "battery": [pick(r, "battery", "Battery") for _, r in df_track.iterrows()],
    "camera_primary": [pick(r, "camera_primary", "camera", "camera_chinh") for _, r in df_track.iterrows()],
    "camera_secondary": [pick(r, "camera_secondary", "camera_phu", "camera_truoc") for _, r in df_track.iterrows()],
    "chipset": [pick(r, "chipset", "Chipset", "cpu") for _, r in df_track.iterrows()],
    "gpu": [pick(r, "gpu", "GPU") for _, r in df_track.iterrows()],
    "wifi": [pick(r, "wifi", "mobile_wifi") for _, r in df_track.iterrows()],
    "location": [pick(r, "province", "location") for _, r in df_track.iterrows()],
    "display_size": [pick(r, "display_size", "Display_Size", "screen_size") for _, r in df_track.iterrows()],
    "screen": [pick(r, "screen", "Screen","mobile_display_features", "display_features") for _, r in df_track.iterrows()],
    "sensor": [pick(r, "sensor", "sensors") for _, r in df_track.iterrows()],
    "watt": [pick(r, "watt", "charging_power", "sac") for _, r in df_track.iterrows()],
    "nfc": [pick(r, "nfc", "NFC") for _, r in df_track.iterrows()],
    "year": pd.to_numeric([pick(r, "year", "release_year", "public_year") for _, r in df_track.iterrows()], errors="coerce"),
    "jack_support": [pick(r, "jack_support", "Jack_Support") for _, r in df_track.iterrows()],
    "price": pd.to_numeric(df_track["price"], errors="coerce")
})

# ======================================================
# 💾 UPSERT (INSERT HOẶC UPDATE)
# ======================================================
for _, row in df_saving.iterrows():
    cursor.execute(f"SELECT 1 FROM {saving_table} WHERE product_id=?", row["product_id"])
    exists = cursor.fetchone()

    # Làm sạch và ép kiểu thật
    price = row["price"]
    if pd.isna(price) or price in [float('inf'), float('-inf')]:
        price = 0.0
    else:
        price = float(price)  # ép numpy.float64 -> float

    year = row["year"]
    if pd.isna(year):
        year = None
    else:
        year = int(year)


    params = (
        row["name"], row["brand"], row["os"], row["ram"], row["rom"], row["battery"],
        row["camera_primary"], row["camera_secondary"], row["chipset"], row["gpu"],
        row["wifi"], row["location"], row["display_size"], row["screen"], row["sensor"],
        row["watt"], row["nfc"], year, row["jack_support"], price, row["product_id"]
    )

    if exists:
        cursor.execute(f"""
            UPDATE {saving_table}
            SET name=?, brand=?, os=?, ram=?, rom=?, battery=?, camera_primary=?, camera_secondary=?,
                chipset=?, gpu=?, wifi=?, location=?, display_size=?, screen=?, sensor=?,
                watt=?, nfc=?, year=?, jack_support=?, price=?
            WHERE product_id=?
        """, params)
    else:
        cursor.execute(f"""
            INSERT INTO {saving_table} (
                product_id, name, brand, os, ram, rom, battery, camera_primary, camera_secondary,
                chipset, gpu, wifi, location, display_size, screen, sensor,
                watt, nfc, year, jack_support, price
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            row["product_id"], row["name"], row["brand"], row["os"], row["ram"], row["rom"], row["battery"],
            row["camera_primary"], row["camera_secondary"], row["chipset"], row["gpu"], row["wifi"],
            row["location"], row["display_size"], row["screen"], row["sensor"],
            row["watt"], row["nfc"], year, row["jack_support"], price
        ))


conn.commit()

# ======================================================
# ✅ CẬP NHẬT PROCESSED
# ======================================================
product_ids = tuple(df_track["product_id"])
if product_ids:
    cursor.execute(f"""
        UPDATE {track_table}
        SET processed = 1
        WHERE product_id IN ({','.join(['?']*len(product_ids))})
    """, product_ids)
    conn.commit()

print(f"🎉 Hoàn tất! {len(df_saving)} sản phẩm đã được upsert vào '{saving_table}'.")
cursor.close()
conn.close()
