import pyodbc
import pandas as pd

# ======================================================
# ⚙️ CẤU HÌNH KẾT NỐI SQL SERVER
# ======================================================
server = r'localhost\SQLEXPRESS'
database = 'blackmen_restore'
track_table = "phones_track"
saving_table = "Phones_Saving"

conn = pyodbc.connect(
    f'DRIVER={{ODBC Driver 18 for SQL Server}};'
    f'SERVER={server};DATABASE={database};'
    f'Trusted_Connection=yes;Encrypt=no;'
)
cursor = conn.cursor()

# ======================================================
# 🧱 TẠO BẢNG PHONES_SAVING NẾU CHƯA CÓ
# ======================================================
create_table_query = f"""
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='{saving_table}' AND xtype='U')
CREATE TABLE {saving_table} (
    product_id NVARCHAR(50) PRIMARY KEY,
    name NVARCHAR(255),
    manufacturer NVARCHAR(100),
    OS NVARCHAR(MAX),
    RAM NVARCHAR(MAX),
    ROM NVARCHAR(50),
    battery NVARCHAR(MAX),
    camera_primary NVARCHAR(MAX),
    camera_secondary NVARCHAR(MAX),
    chipset NVARCHAR(100),
    GPU NVARCHAR(100),
    display_size NVARCHAR(50),
    screen NVARCHAR(MAX),
    mobile_type_of_display NVARCHAR(MAX),
    visibility NVARCHAR(50),
    nfc NVARCHAR(50),
    jack_support NVARCHAR(50),
    price FLOAT
)
"""
cursor.execute(create_table_query)
conn.commit()
print(f"✅ Bảng '{saving_table}' đã sẵn sàng (nếu chưa tồn tại).")

# ======================================================
# 🧾 LẤY DỮ LIỆU CHƯA XỬ LÝ
# ======================================================
df_track = pd.read_sql(f"""
    SELECT * FROM {track_table}
    WHERE processed = 0 OR processed IS NULL
""", conn)

if df_track.empty:
    print("🟢 Không có dữ liệu mới để xử lý.")
    cursor.close()
    conn.close()
    exit()

print(f"🟢 Dữ liệu mới: {len(df_track)} bản ghi")

# ======================================================
# 🔧 HÀM PICK GIÁ TRỊ LINH HOẠT
# ======================================================
def pick(row, *keys):
    for k in keys:
        if k in row and pd.notna(row[k]):
            return row[k]
    return None

# ======================================================
# 💼 CHUẨN HÓA BRAND
# ======================================================
brand_map = {
    "samsung": "Samsung", "galaxy": "Samsung",
    "xiaomi": "Xiaomi", "oppo": "Oppo", "vivo": "Vivo", "realme": "Realme",
    "huawei": "Huawei", "oneplus": "OnePlus", "google": "Google", "sony": "Sony",
    "cubot": "Cubot", "htc": "HTC", "lenovo": "Lenovo", "t-mobile": "T-Mobile",
    "tecno": "Tecno", "walton": "Walton", "infinix": "Infinix", "honor": "Honor",
    "motorola": "Motorola", "nokia": "Nokia", "zte": "ZTE", "tcl": "TCL",
    "meizu": "Meizu", "doogee": "Doogee", "nubia": "Nubia", "nothingphone": "NothingPhone",
    "itel": "Itel", "masstel": "Masstel", "viettel": "Viettel", "tesla": "Tesla"
}

def infer_brand(row):
    brand_lower = str(row["manufacturer"]).lower()
    if brand_lower == "hãng khác":
        name_lower = str(row["name"]).lower()
        for keyword, brand in brand_map.items():
            if keyword in name_lower:
                return brand
    return row["manufacturer"]

# Áp dụng brand
df_track["manufacturer"] = df_track.apply(infer_brand, axis=1)

# Lưu lại brand vào track
for _, row in df_track.iterrows():
    cursor.execute("""
        UPDATE phones_track
        SET manufacturer = ?
        WHERE product_id = ?
    """, row["manufacturer"], row["product_id"])
conn.commit()
print("✅ Brand đã được chuẩn hóa và cập nhật vào bảng track.")

# ======================================================
# 🧩 TẠO DATAFRAME CHUẨN HÓA CHO SAVING
# ======================================================
df_saving = pd.DataFrame({
    "product_id": df_track["product_id"],
    "name": df_track["name"],
    "manufacturer": df_track["manufacturer"],
    "OS": [pick(r, "OS", "os") for _, r in df_track.iterrows()],
    "RAM": [pick(r, "RAM", "ram", "memory_internal") for _, r in df_track.iterrows()],
    "ROM": [pick(r, "ROM", "rom", "storage") for _, r in df_track.iterrows()],
    "battery": [pick(r, "Battery", "battery", "pin") for _, r in df_track.iterrows()],
    "camera_primary": [pick(r, "camera_primary", "camera", "camera_chinh") for _, r in df_track.iterrows()],
    "camera_secondary": [pick(r, "camera_secondary", "camera_phu", "camera_truoc") for _, r in df_track.iterrows()],
    "chipset": [pick(r, "Chipset", "chipset", "cpu", "chip") for _, r in df_track.iterrows()],
    "GPU": [pick(r, "GPU", "gpu") for _, r in df_track.iterrows()],
    "display_size": [pick(r, "Display_Size", "display_size", "man_hinh") for _, r in df_track.iterrows()],
    "screen": [pick(r, "Screen", "screen","mobile_display_features", "display_features") for _, r in df_track.iterrows()],
    "mobile_type_of_display": [pick(r, "mobile_type_of_display", "display_type") for _, r in df_track.iterrows()],
    "visibility": [pick(r, "Visibility", "visibility_date", "release_date", "ra_mat", "ngay_ra_mat") for _, r in df_track.iterrows()],
    "nfc": [pick(r, "NFC", "nfc", "mobile_nfc") for _, r in df_track.iterrows()],
    "jack_support": [pick(r, "Jack_Support", "jack_support", "mobile_jack_tai_nghe") for _, r in df_track.iterrows()],
    "price": [pick(r, "price") for _, r in df_track.iterrows()]
})

# ======================================================
# 💾 UPSERT ROW-BY-ROW VÀO PHONES_SAVING
# ======================================================
for _, row in df_saving.iterrows():
    # Kiểm tra tồn tại
    cursor.execute(f"SELECT 1 FROM {saving_table} WHERE product_id=?", row["product_id"])
    exists = cursor.fetchone()
    
    if exists:
        # Update
        cursor.execute(f"""
            UPDATE {saving_table} SET
                name=?, manufacturer=?, OS=?, RAM=?, ROM=?, battery=?,
                camera_primary=?, camera_secondary=?, chipset=?, GPU=?,
                display_size=?, screen=?, mobile_type_of_display=?, visibility=?, nfc=?, jack_support=?, price=?
            WHERE product_id=?
        """,
        row["name"], row["manufacturer"], row["OS"], row["RAM"], row["ROM"], row["battery"],
        row["camera_primary"], row["camera_secondary"], row["chipset"], row["GPU"],
        row["display_size"], row["screen"], row["mobile_type_of_display"], row["visibility"], row["nfc"], row["jack_support"], row["price"],
        row["product_id"])
    else:
        # Insert
        cursor.execute(f"""
            INSERT INTO {saving_table} (
                product_id, name, manufacturer, OS, RAM, ROM, battery,
                camera_primary, camera_secondary, chipset, GPU,
                display_size, screen, mobile_type_of_display, visibility, nfc, jack_support, price
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        row["product_id"], row["name"], row["manufacturer"], row["OS"], row["RAM"], row["ROM"], row["battery"],
        row["camera_primary"], row["camera_secondary"], row["chipset"], row["GPU"],
        row["display_size"], row["screen"], row["mobile_type_of_display"], row["visibility"], row["nfc"], row["jack_support"], row["price"])

# UPDATE
row["name"], row["manufacturer"], row["OS"], row["RAM"], row["ROM"], row["battery"],
row["camera_primary"], row["camera_secondary"], row["chipset"], row["GPU"],
row["display_size"], row["screen"], row["mobile_type_of_display"], row["visibility"], row["nfc"], row["jack_support"], row["price"],
row["product_id"],
# INSERT
row["product_id"], row["name"], row["manufacturer"], row["OS"], row["RAM"], row["ROM"], row["battery"],
row["camera_primary"], row["camera_secondary"], row["chipset"], row["GPU"],
row["display_size"], row["screen"], row["mobile_type_of_display"], row["visibility"], row["nfc"], row["jack_support"], row["price"]


conn.commit()

# ======================================================
# ✅ CẬP NHẬT PROCESSED = 1
# ======================================================
product_ids = tuple(df_track["product_id"])
if product_ids:
    cursor.execute(f"""
        UPDATE {track_table}
        SET processed = 1
        WHERE product_id IN ({','.join(['?']*len(product_ids))})
    """, product_ids)
    conn.commit()

# ======================================================
# 📝 LOGGING
# ======================================================
print(f"🎉 Hoàn tất! {len(df_saving)} sản phẩm đã được upsert vào '{saving_table}' và đánh dấu processed = 1.")
cursor.close()
conn.close()
