from utils.elastic_utils import upload_to_elasticsearch

def process_and_upload(raw_data):
    # Xử lý nếu cần
    processed_data = raw_data  # hoặc thêm bước làm sạch ở đây

    # Upload lên Elasticsearch
    upload_to_elasticsearch(
        index_name="phones_hanoi",
        data=processed_data,
        cloud_id="https://e72eb8c5112142169a3526c1c5f70827.us-central1.gcp.cloud.es.io:443",
        username="elastic",
        password="0yuFCrOPja8ayu869DtFUhN7"
    )
