import os
import sys
import requests
import time

# ==== Đảm bảo luôn import đúng config của RawData ====
RAW_DIR = os.path.dirname(__file__)
sys.path.insert(0, RAW_DIR)

from config import URL, HEADERS, CATEGORY_ID, MAX_PAGES
from province_list import province_list


def fetch_products():
    all_products = []

    for province_id, province_name in province_list.items():
        print(f"\n🏙️ Đang lấy dữ liệu cho {province_name} (ID = {province_id})")

        for page in range(1, MAX_PAGES + 1):
            print(f"   📄 Trang {page}...")

            payload = {
                "query": f"""
                query GetProductsByCateId{{
                    products(
                        filter: {{
                            static: {{
                                categories: ["{CATEGORY_ID}"],
                                province_id: {province_id},
                                stock: {{ from: 0 }},
                                stock_available_id: [46, 56, 152, 4920],
                                filter_price: {{ from: 0, to: 63990000 }}
                            }},
                            dynamic: {{}}
                        }},
                        page: {page},
                        size: 500,
                        sort: [{{view: desc}}]
                    ){{
                        general{{
                            product_id
                            name
                            manufacturer
                            attributes
                            sku
                            url_key
                            categories{{ categoryId name }}
                            review{{ total_count average_rating }}
                        }},
                        filterable{{
                            price
                            special_price
                            is_installment
                            stock_available_id
                            promotion_information
                            flash_sale_types
                        }}
                    }}
                }}
                """,
                "variables": {}
            }

            try:
                res = requests.post(URL, headers=HEADERS, json=payload)
                if res.status_code != 200:
                    print(f"   ❌ HTTP {res.status_code}, bỏ qua {province_name}.")
                    break

                data = res.json()
                products = data.get("data", {}).get("products", [])
                if not products:
                    print(f"   ⚠️ Trang {page} không có dữ liệu, dừng lại.")
                    break

                for p in products:
                    p["province_id"] = province_id
                    p["province_name"] = province_name

                all_products.extend(products)
                print(f"   ✅ Lấy xong trang {page}, tổng cộng {len(all_products)} sản phẩm.")
                time.sleep(1)

            except Exception as e:
                print(f"   ⚠️ Lỗi khi lấy dữ liệu: {e}")
                break

    print(f"\n🎯 Hoàn tất! Tổng cộng {len(all_products)} sản phẩm lấy được.")
    return all_products


# ============= Hàm chuẩn hóa trả về DataFrame cho pipeline =============
import pandas as pd

def get_raw_dataframe():
    products = fetch_products()
    df = pd.DataFrame(products)
    return df
