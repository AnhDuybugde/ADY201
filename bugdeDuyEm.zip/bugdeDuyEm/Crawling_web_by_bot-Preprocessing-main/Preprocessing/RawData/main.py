from scraper import fetch_products
from parser import parse_product
import pandas as pd

def run_raw_pipeline():
    print("🚀 Bắt đầu tiến trình cào và xử lý dữ liệu thô...\n")

    # 1️⃣ Cào dữ liệu từ API
    raw_products = fetch_products()

    # 2️⃣ Parse từng sản phẩm sang dạng tuple
    parsed_rows = [parse_product(p) for p in raw_products]

    # 3️⃣ Chuyển sang DataFrame để dễ xử lý ở Processing
    columns = [
        "product_id", "name", "manufacturer", "price", "special_price",
        "battery", "camera_primary", "camera_secondary", "chipset",
        "display_size", "gpu", "memory_internal", "mobile_display_features",
        "mobile_type_of_display", "storage", "release_date", "year",
        "nfc", "jack_support", "OS", "wifi", "sensor", "watt", "processed"
    ]
    df = pd.DataFrame(parsed_rows, columns=columns)

    print(f"\n✅ Hoàn tất RawData pipeline! Tổng {len(df)} sản phẩm đã được cào.")
    return df

if __name__ == "__main__":
    df = run_raw_pipeline()
    print(df.head())
