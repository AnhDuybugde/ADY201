import os
from dotenv import load_dotenv
import pyodbc

# ==========================
# 📁 Đường dẫn tới file .env
# ==========================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ENV_PATH = os.path.join(BASE_DIR, ".env")

if not os.path.exists(ENV_PATH):
    raise FileNotFoundError(f"❌ Không tìm thấy file .env tại: {ENV_PATH}")

load_dotenv(ENV_PATH)

# ==========================
# 🧱 Đọc cấu hình từ .env
# ==========================
SQL_SERVER = os.getenv("SQL_SERVER")
SQL_DATABASE = os.getenv("SQL_DATABASE")
SQL_AUTH = os.getenv("SQL_AUTH", "windows").lower()
SQL_DRIVER = os.getenv("SQL_DRIVER", "ODBC Driver 17 for SQL Server")

TABLE_NAME = os.getenv("TABLE_NAME", "phones_track")
SAVING_TABLE = os.getenv("SAVING_TABLE", "phones_processed")

URL = os.getenv("URL")
CATEGORY_ID = os.getenv("CATEGORY_ID", "3")
MAX_PAGES = int(os.getenv("MAX_PAGES", 100))
PROVINCE_ID = os.getenv("PROVINCE_ID", "ALL")
USER_AGENT = os.getenv("USER_AGENT", "Mozilla/5.0")

# ==========================
# ☁️ Elasticsearch
# ==========================
ELASTIC_CLOUD_ID = os.getenv("ELASTIC_CLOUD_ID")
ELASTIC_API_KEY = os.getenv("ELASTIC_API_KEY")
ELASTIC_INDEX = os.getenv("ELASTIC_INDEX", "phones_all_vietnam")

# ==========================
# 🌍 HTTP HEADERS (cho scraper)
# ==========================
HEADERS = {
    "User-Agent": USER_AGENT,
    "Content-Type": "application/json",
}

# ==========================
# 🧩 Kết nối SQL Server
# ==========================
def get_connection():
    """Kết nối SQL Server (Windows hoặc SQL Auth)"""
    if not SQL_SERVER or not SQL_DATABASE:
        raise ValueError(f"❌ Thiếu cấu hình trong file .env tại: {ENV_PATH}\n"
                         f"Thiếu: SERVER hoặc DATABASE")

    if SQL_AUTH == "windows":
        conn_str = (
            f"DRIVER={{{SQL_DRIVER}}};"
            f"SERVER={SQL_SERVER};"
            f"DATABASE={SQL_DATABASE};"
            "Trusted_Connection=yes;"
        )
    else:
        sql_user = os.getenv("SQL_USER")
        sql_pass = os.getenv("SQL_PASSWORD")
        if not sql_user or not sql_pass:
            raise ValueError("❌ Thiếu SQL_USER hoặc SQL_PASSWORD trong .env (khi dùng SQL Auth).")

        conn_str = (
            f"DRIVER={{{SQL_DRIVER}}};"
            f"SERVER={SQL_SERVER};"
            f"DATABASE={SQL_DATABASE};"
            f"UID={sql_user};PWD={sql_pass};"
        )

    return pyodbc.connect(conn_str)

