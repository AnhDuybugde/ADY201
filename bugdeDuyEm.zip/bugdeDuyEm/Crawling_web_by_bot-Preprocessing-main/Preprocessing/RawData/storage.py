# src/storage.py
from config import get_connection, TABLE_NAME
from datetime import datetime

def create_table():
    conn = get_connection()
    cursor = conn.cursor()

    # Tạo bảng nếu chưa có
    cursor.execute(f"""
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='{TABLE_NAME}' AND xtype='U')
    BEGIN
        CREATE TABLE {TABLE_NAME} (
            product_id NVARCHAR(50),
            name NVARCHAR(255),
            manufacturer NVARCHAR(100),
            price FLOAT,
            special_price FLOAT,
            battery NVARCHAR(255),
            camera_primary NVARCHAR(MAX),
            camera_secondary NVARCHAR(MAX),
            chipset NVARCHAR(255),
            display_size NVARCHAR(100),
            gpu NVARCHAR(255),
            memory_internal NVARCHAR(255),
            mobile_display_features NVARCHAR(MAX),
            mobile_type_of_display NVARCHAR(255),
            storage NVARCHAR(255),
            release_date DATETIME NULL,
            year INT NULL,
            nfc NVARCHAR(50),
            jack_support NVARCHAR(50),
            OS NVARCHAR(255),
            wifi NVARCHAR(255),
            sensor NVARCHAR(MAX),
            watt NVARCHAR(MAX),
            processed BIT NULL DEFAULT 0,
            crawl_time DATETIME DEFAULT GETDATE()
        )
    END
    """)

    # Nếu bảng đã có mà thiếu cột crawl_time thì thêm
    cursor.execute(f"""
    IF COL_LENGTH('dbo.{TABLE_NAME}', 'crawl_time') IS NULL
    BEGIN
        ALTER TABLE dbo.{TABLE_NAME}
        ADD crawl_time DATETIME DEFAULT GETDATE()
    END
    """)

    conn.commit()
    conn.close()
    print(f"✅ Bảng '{TABLE_NAME}' đã sẵn sàng và có cột crawl_time.")


def insert_many(rows):
    conn = get_connection()
    cursor = conn.cursor()
    crawl_time = datetime.now()

    # ❗ Không liệt kê crawl_time trong danh sách cột
    insert_query = f"""
    INSERT INTO {TABLE_NAME} (
        product_id, name, manufacturer, price, special_price,
        battery, camera_primary, camera_secondary, chipset,
        display_size, gpu, memory_internal, mobile_display_features,
        mobile_type_of_display, storage, release_date, year,
        nfc, jack_support, OS, wifi, sensor, watt, processed
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """

    for row in rows:
        cursor.execute(insert_query, row)

    conn.commit()
    conn.close()
    print(f"🎉 Đã lưu {len(rows)} sản phẩm vào '{TABLE_NAME}' với crawl_time = {crawl_time}")

