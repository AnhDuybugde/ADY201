@echo off
title 🚀 Auto Data Pipeline - RawData + Processing
cd /d "D:\Triet\FALL25\ADY\Crawling_web_by Duy_bot_bugde\Crawling_web_by_bot-Preprocessing-main\Preprocessing"

echo ============================================
echo 🚀 Bắt đầu tiến trình cào dữ liệu (RawData)...
echo ============================================
python RawData\main.py
if %errorlevel% neq 0 (
    echo ❌ Lỗi khi cào dữ liệu. Dừng quy trình.
    pause
    exit /b
)

echo.
echo ============================================
echo ⚙️ Bắt đầu xử lý dữ liệu (Processing)...
echo ============================================
python Processing\main.py
if %errorlevel% neq 0 (
    echo ❌ Lỗi khi xử lý dữ liệu. Dừng quy trình.
    pause
    exit /b
)

echo.
echo ============================================
echo ✅ Hoàn tất toàn bộ tiến trình!
echo ============================================
pause
