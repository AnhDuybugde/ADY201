import pandas as pd
from elasticsearch import Elasticsearch, helpers

# ===============================
# ⚙️ Kết nối tới Elasticsearch
# ===============================
def get_es_client():
    """
    Trả về một Elasticsearch client đã kết nối sẵn.
    """
    es = Elasticsearch(
        ["https://e72eb8c5112142169a3526c1c5f70827.us-central1.gcp.cloud.es.io:443"],
        api_key="MDlXWlBab0I4RHFXM24wdHlrRWQ6bUxQRlBheFZwNHBEZUFqM1RGWldRdw=="
    )

    # Kiểm tra kết nối
    if not es.ping():
        raise ConnectionError("❌ Không thể kết nối tới Elasticsearch server.")
    print("✅ Đã kết nối thành công tới Elasticsearch.")
    return es


# ===============================
# 📤 Upload dữ liệu lên Elasticsearch
# ===============================
def upload_to_elasticsearch(es, df: pd.DataFrame, index_name: str):
    """
    Upload toàn bộ DataFrame lên Elasticsearch theo dạng bulk để tối ưu tốc độ.
    """

    if df.empty:
        print("⚠️ DataFrame trống, không có gì để upload.")
        return

    # Chuyển DataFrame thành list các document
    actions = [
        {
            "_index": index_name,
            "_source": row.to_dict()
        }
        for _, row in df.iterrows()
    ]

    # Dùng helpers.bulk để insert nhanh
    success, failed = 0, 0
    try:
        helpers.bulk(es, actions)
        success = len(actions)
        print(f"✅ Đã upload {success} tài liệu lên index '{index_name}'.")
    except Exception as e:
        failed = len(actions)
        print(f"❌ Lỗi khi upload lên Elasticsearch: {e}")
    finally:
        print(f"📊 Tổng số dòng xử lý: {len(actions)} | Thành công: {success} | Thất bại: {failed}")
