import os
import time
import requests
import pandas as pd
from elasticsearch import Elasticsearch, helpers

# ======================
# 1️⃣ Import config
# ======================
from config import URL, HEADERS, CATEGORY_ID, MAX_PAGES
from province_list import province_list


# ======================
# 2️⃣ Hàm cào dữ liệu
# ======================
def fetch_products():
    all_products = []

    for province_id, province_name in province_list.items():
        print(f"\n🏙️ Đang lấy dữ liệu cho {province_name} (ID = {province_id})")

        for page in range(1, MAX_PAGES + 1):
            print(f"   📄 Trang {page}...")

            payload = {
                "query": f"""
                query GetProductsByCateId{{
                    products(
                        filter: {{
                            static: {{
                                categories: ["{CATEGORY_ID}"],
                                province_id: {province_id},
                                stock: {{ from: 0 }},
                                stock_available_id: [46, 56, 152, 4920],
                                filter_price: {{ from: 0, to: 63990000 }}
                            }},
                            dynamic: {{}}
                        }},
                        page: {page},
                        size: 500,
                        sort: [{{view: desc}}]
                    ){{
                        general{{
                            product_id
                            name
                            manufacturer
                            attributes
                            sku
                            url_key
                            categories{{ categoryId name }}
                            review{{ total_count average_rating }}
                        }},
                        filterable{{
                            price
                            special_price
                            is_installment
                            stock_available_id
                            promotion_information
                            flash_sale_types
                        }}
                    }}
                }}
                """,
                "variables": {}
            }

            try:
                res = requests.post(URL, headers=HEADERS, json=payload)
                if res.status_code != 200:
                    print(f"   ❌ HTTP {res.status_code}, bỏ qua {province_name}.")
                    break

                data = res.json()
                products = data.get("data", {}).get("products", [])
                if not products:
                    print(f"   ⚠️ Trang {page} không có dữ liệu, dừng lại.")
                    break

                for p in products:
                    p["province_id"] = province_id
                    p["province_name"] = province_name

                all_products.extend(products)
                print(f"   ✅ Trang {page}: tổng {len(all_products)} sản phẩm.")
                time.sleep(0.8)

            except Exception as e:
                print(f"   ⚠️ Lỗi khi lấy dữ liệu: {e}")
                break

    print(f"\n🎯 Hoàn tất! Tổng cộng {len(all_products)} sản phẩm lấy được.")
    return all_products


# ======================
# 3️⃣ Trả về DataFrame
# ======================
def get_raw_dataframe():
    products = fetch_products()
    df = pd.DataFrame(products)
    return df


# ======================
# 4️⃣ Upload Elasticsearch
# ======================
def upload_to_elasticsearch(df):
    es = Elasticsearch(
        "https://e72eb8c5112142169a3526c1c5f70827.us-central1.gcp.cloud.es.io:443",
        api_key="VUFFVlI1b0JTdWlYUENIT3FSRG86bUN3REh4cHY2bWdDWHpaMUpEOGdiQQ=="
    )

    index_name = "rawdata_phones"

    actions = []
    for _, row in df.iterrows():
        try:
            _id = None
            if isinstance(row.get("general"), dict) and "product_id" in row["general"]:
                _id = str(row["general"]["product_id"])

            actions.append({
                "_index": index_name,
                "_id": _id,
                "_source": row.to_dict()
            })
        except Exception as e:
            print(f"⚠️ Bỏ qua 1 dòng lỗi: {e}")

    helpers.bulk(es, actions)
    print(f"✅ Đã upload {len(actions)} bản ghi lên Elasticsearch index '{index_name}'.")


# ======================
# 5️⃣ Main
# ======================
if __name__ == "__main__":
    df = get_raw_dataframe()
    upload_to_elasticsearch(df)
