from ibm_watson_machine_learning import APIClient

def upload_to_watsonx_ai(df):
    # Cấu hình kết nối watsonx.ai
    wml_credentials = {
        "apikey": "BqXMfz8Ravko-tA1BacKzPxxoFysobsXPK3U8TugvoYO",
        "url": "https://jp-tok.ml.cloud.ibm.com"
    }

    client = APIClient(wml_credentials)

    # ID project mà bạn copy trong mục Developer access
    project_id = "PASTE_YOUR_PROJECT_ID_HERE"

    # Lưu dữ liệu tạm thành file CSV
    file_name = "phones_raw.csv"
    df.to_csv(file_name, index=False, encoding="utf-8-sig")
    print(f"💾 Đã lưu tạm file {file_name}")

    # Upload file vào project
    client.data_assets.create(
        name="Phones Raw Data",
        file_path=file_name,
        project_id=project_id
    )

    print("✅ Đã upload dataset thành công lên project watsonx.ai!")
