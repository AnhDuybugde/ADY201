from elasticsearch import Elasticsearch

# Kết nối Elasticsearch Cloud
es = Elasticsearch(
    "https://e72eb8c5112142169a3526c1c5f70827.us-central1.gcp.cloud.es.io:443",
    api_key="VUFFVlI1b0JTdWlYUENIT3FSRG86bUN3REh4cHY2bWdDWHpaMUpEOGdiQQ=="
)

# Lấy danh sách tất cả index
indices = list(es.indices.get_alias(index="*").keys())
print("Các index hiện tại:", indices)

# Xóa các index cũ
for idx in indices:
    if "processed_phones" in idx or "rawdata_phones" in idx:
        es.indices.delete(index=idx)
        print(f"Đã xóa index: {idx}")

print("Hoàn tất xóa index cũ.")
