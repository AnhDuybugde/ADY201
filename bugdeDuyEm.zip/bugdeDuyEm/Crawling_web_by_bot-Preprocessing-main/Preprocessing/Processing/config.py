# Processing/config.py
import os
from dotenv import load_dotenv
import pyodbc

# --- Load .env từ folder gốc Preprocessing ---
ENV_PATH = os.path.join(os.path.dirname(__file__), "../.env")
load_dotenv(ENV_PATH)

# --- SQL Server ---
SQL_SERVER = os.getenv("SQL_SERVER")
SQL_DATABASE = os.getenv("SQL_DATABASE")
SQL_DRIVER = os.getenv("SQL_DRIVER")
SQL_AUTH = os.getenv("SQL_AUTH", "windows").lower()

# --- Elasticsearch ---
ELASTIC_CLOUD_ID = os.getenv("ELASTIC_CLOUD_ID")
ELASTIC_API_KEY = os.getenv("ELASTIC_API_KEY")
ELASTIC_INDEX = os.getenv("ELASTIC_INDEX")

# --- Hàm kết nối SQL Server ---
def get_connection():
    if SQL_AUTH == "windows":
        conn_str = f"Driver={{ {SQL_DRIVER} }};Server={SQL_SERVER};Database={SQL_DATABASE};Trusted_Connection=yes;"
    else:
        SQL_USER = os.getenv("SQL_USER")
        SQL_PASSWORD = os.getenv("SQL_PASSWORD")
        conn_str = f"Driver={{ {SQL_DRIVER} }};Server={SQL_SERVER};Database={SQL_DATABASE};UID={SQL_USER};PWD={SQL_PASSWORD};"
    return pyodbc.connect(conn_str)
