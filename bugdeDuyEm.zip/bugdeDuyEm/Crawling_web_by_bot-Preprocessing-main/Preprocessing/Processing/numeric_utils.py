import pandas as pd
import re

# ======================================================
# 🔢 Chuẩn hóa các cột numeric (RAM, ROM, watt, nfc, price…)
# ======================================================
def clean_numeric_column(df, col_list):
    """
    Chuyển các cột numeric sang float hợp lệ.
    - Lấy số đầu tiên từ chuỗi
    - NaN / None → None để SQL Server nhận NULL
    """
    for col in col_list:
        if col in df.columns:
            def extract_number(val):
                if pd.isna(val):
                    return None
                nums = re.findall(r'\d+\.?\d*', str(val))
                return float(nums[0]) if nums else None
            df[col] = df[col].apply(extract_number)
    return df

# ======================================================
# 🧩 Test nhanh
# ======================================================
if __name__ == "__main__":
    df = pd.DataFrame({
        "ram": ["12 GB", "8GB + Mở rộng 8GB", None],
        "watt": ["5000 mAh", "4500", ""],
        "price": ["1000", "1200", None]
    })
    df = clean_numeric_column(df, ["ram", "watt", "price"])
    print(df)
