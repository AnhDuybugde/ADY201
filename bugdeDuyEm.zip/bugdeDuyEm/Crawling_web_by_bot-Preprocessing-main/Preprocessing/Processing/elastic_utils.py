import pandas as pd
from elasticsearch import Elasticsearch, helpers
from dotenv import load_dotenv
import os

load_dotenv()

ELASTIC_HOST = os.getenv("ELASTIC_HOST")
ELASTIC_API_KEY = os.getenv("ELASTIC_API_KEY")
INDEX_NAME = os.getenv("ELASTIC_INDEX")

# Kết nối Elasticsearch Cloud
def get_es_client():
    return Elasticsearch(
        hosts=[ELASTIC_HOST],
        api_key=ELASTIC_API_KEY,
    )

# Hàm upsert dữ liệu lên Elasticsearch
def upload_to_elasticsearch(df: pd.DataFrame, es_client):
    if df.empty:
        print("⚠️ Không có dữ liệu để upload lên Elasticsearch.")
        return

    actions = []
    for _, row in df.iterrows():
        actions.append({
            "_index": INDEX_NAME,
            "_id": row.get("product_id", None),
            "_source": row.to_dict()
        })

    helpers.bulk(es_client, actions)
    print(f"✅ Đã upload {len(df)} bản ghi lên index '{INDEX_NAME}' thành công!")
