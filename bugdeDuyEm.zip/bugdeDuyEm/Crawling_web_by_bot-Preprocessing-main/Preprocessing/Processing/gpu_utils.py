# gpu_utils.py
import pandas as pd

# ======================================================
# 🔢 Hàm phân loại GPU
# ======================================================
def gpu_performance_bin(gpu):
    """
    Phân loại GPU thành High / Mid / Low / NULL
    """
    if pd.isna(gpu) or str(gpu).strip() == "":
        return None

    gpu_lower = str(gpu).lower().strip()

    # 🔺 High-end
    high_gpus = [
        "adreno 73", "adreno 74", "adreno 75", "adreno™ 730",
        "mali-g78", "mali-g710", "mali-g710 mc", "mali-g615",
        "immortalis", "xclipse", "apple gpu (5", "apple gpu 5 nhân",
        "gpu 6 lõi", "gpu 6 lõi mới", "gpu 5 lõi", "gpu 5 lõi mới",
        "mali-g76 mp", "mali-g72 mp", "mali-g77 mp", "mali-g77 mc",
        "apple gpu 4-core", "apple gpu"
    ]
    if any(h in gpu_lower for h in high_gpus):
        return "High"

    # 🔹 Mid-range
    mid_gpus = [
        "adreno 66", "adreno 67", "adreno 71", "adreno 72",
        "adreno 644", "adreno 642", "adreno 642l", "adreno 650",
        "adreno 619", "adreno 618", "adreno 612", "adreno 610",
        "adreno™ 610", "adreno™ 619", "mali-g68", "mali-g610",
        "mali-g57", "mali g57", "arm mali g57", "mali-g52",
        "mali g52", "arm mail g52", "arm mali-g72 mp3", "arm g57",
        "mali-g51", "powervr gm", "powervr8320", "amd titan",
        "mt676", "qualcomm® adreno", "img"
    ]
    if any(m in gpu_lower for m in mid_gpus):
        return "Mid"

    # ⚪ Low-end
    low_gpus = [
        "adreno 50", "powervr ge", "ge8320", "ge8322", "4-core gpu",
        "gpu 4 nhân", "gpu 5 lõi với neural", "gpu 6 lõi với neural",
        "4nm tsmc", "null", "ram", "rom", "sm-a146b", "sm-a146p"
    ]
    if any(l in gpu_lower for l in low_gpus):
        return "Low"

    # Mặc định
    return None

# ======================================================
# 🧩 Hàm xử lý DataFrame
# ======================================================
def process_gpu(df):
    """
    Tạo cột GPU_Performance dựa trên nhãn GPU.
    """
    gpu_col = next((c for c in df.columns if c.lower() in ["gpu", "gpu_name"]), None)
    if gpu_col is None:
        raise KeyError("DataFrame không có cột gpu/gpu_name.")

    df["gpu"] = df[gpu_col].apply(gpu_performance_bin)
    return df

# ======================================================
# 🧩 Ví dụ sử dụng
# ======================================================
if __name__ == "__main__":
    data = {
        "gpu": [
            "Adreno 730", "Mali-G52", "PowerVR GE8320", None, "Apple GPU 5 nhân"
        ]
    }
    df = pd.DataFrame(data)
    df = process_gpu(df)
    print(df)
