# Processing/upload_to_elastic.py
import pandas as pd
from elasticsearch import Elasticsearch, helpers
from dotenv import load_dotenv
import os

# ---- Load cấu hình từ .env ----
load_dotenv()

ES_CLOUD_ID = os.getenv("ELASTIC_CLOUD_ID")
ES_API_KEY = os.getenv("ELASTIC_API_KEY")
INDEX_NAME = os.getenv("ELASTIC_INDEX")
DATA_FILE = os.getenv("PROCESSED_CSV", "Processing/phones_processed.csv")  # CSV sau xử lý

# ---- Đọc dữ liệu đã xử lý ----
df = pd.read_csv(DATA_FILE)
print(f"📦 Đang chuẩn bị đẩy {len(df)} bản ghi lên Elasticsearch...")

# ---- Kết nối Elasticsearch Cloud ----
es = Elasticsearch(
    ES_CLOUD_ID,
    api_key=ES_API_KEY,
)

# ---- Push dữ liệu hàng loạt ----
actions = [
    {
        "_index": INDEX_NAME,
        "_id": str(row["product_id"]),
        "_source": row.to_dict(),
    }
    for _, row in df.iterrows()
]

helpers.bulk(es, actions)
print(f"✅ Đã đẩy {len(actions)} bản ghi lên Elasticsearch index '{INDEX_NAME}'")

