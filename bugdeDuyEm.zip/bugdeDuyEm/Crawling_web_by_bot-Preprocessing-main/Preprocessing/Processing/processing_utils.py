import pandas as pd
from price_handle_utils import compute_final_price
from brand_utils import infer_brand
from os_utils import process_os
from ram_utils import process_ram
from rom_utils import process_rom
from battery_utils import process_battery
from camera_utils import process_camera
from chipset_utils import process_chipset
from gpu_utils import process_gpu
from display_size_utils import process_display
from screen_utils import process_screen
from sensor_utils import process_sensor
from nfc_utils import process_nfc_column
from jack_support_utils import process_jack_support
from numeric_utils import clean_numeric_column
from normalize import normalize_for_saving

def process_dataframe(df_raw: pd.DataFrame) -> pd.DataFrame:
    """
    Xử lý, chuẩn hóa và lọc dữ liệu từ RawData
    """
    if df_raw.empty:
        return pd.DataFrame()

    # ----- Xử lý giá -----
    df_raw = compute_final_price(df_raw)

    # ----- Chuẩn hóa brand -----
    df_raw["manufacturer"] = df_raw.apply(infer_brand, axis=1)

    # ----- Xử lý các cột kỹ thuật -----
    df_raw = process_os(df_raw)
    df_raw = process_ram(df_raw)
    df_raw = process_rom(df_raw)
    df_raw = process_battery(df_raw)
    df_raw = process_camera(df_raw)
    df_raw = process_chipset(df_raw)
    df_raw = process_gpu(df_raw)
    df_raw = process_display(df_raw)
    df_raw = process_screen(df_raw)
    df_raw = process_sensor(df_raw)
    df_raw = process_nfc_column(df_raw)
    df_raw = process_jack_support(df_raw)

    # ----- Chuẩn hóa các cột số -----
    df_raw = clean_numeric_column(df_raw, ["ram", "storage", "battery", "watt", "price"])

    # ----- Chuẩn hóa cuối trước khi upload -----
    df_processed = normalize_for_saving(df_raw)

    # ----- Lọc sản phẩm nếu muốn (ví dụ giá > 0) -----
    df_processed = df_processed[df_processed["price"] > 0]

    return df_processed
