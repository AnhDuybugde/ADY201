from elasticsearch import Elasticsearch

url = "https://e72eb8c5112142169a3526c1c5f70827.us-central1.gcp.cloud.es.io:443"
api_key = "VUFFVlI1b0JTdWlYUENIT3FSRG86bUN3REh4cHY2bWdDWHpaMUpEOGdiQQ=="

# Khởi tạo client
es = Elasticsearch(
    url,
    api_key=api_key
)

# Kiểm tra kết nối
print(es.info())

# Liệt kê tất cả index
indices = list(es.indices.get_alias(index="*").keys())
print(indices)
