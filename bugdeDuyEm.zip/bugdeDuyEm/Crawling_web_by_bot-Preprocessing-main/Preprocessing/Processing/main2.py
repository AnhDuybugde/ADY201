import pandas as pd
from elasticsearch import Elasticsearch, helpers
from elasticsearch.helpers import scan
from elasticsearch import helpers
import json
# ====== KẾT NỐI ELASTICSEARCH ======
es = Elasticsearch(
    "https://e72eb8c5112142169a3526c1c5f70827.us-central1.gcp.cloud.es.io:443",
    api_key="VUFFVlI1b0JTdWlYUENIT3FSRG86bUN3REh4cHY2bWdDWHpaMUpEOGdiQQ=="
)

RAW_INDEX = "rawdata_phones"
PROCESSED_INDEX = "processed_phones"


# ====== HÀM HỖ TRỢ ======
def fetch_from_elasticsearch(index_name):
    print(f"📥 Đang tải dữ liệu từ Elasticsearch index '{index_name}'...")
    results, ids = [], []
    for doc in scan(es, index=index_name):
        results.append(doc["_source"])
        ids.append(doc["_id"])
    df = pd.DataFrame(results)
    df["product_id"] = ids
    print(f"✅ Đã lấy {len(df)} bản ghi từ Elasticsearch.")
    return df


def expand_nested_columns(df, colname):
    """Bung các dict bên trong general/filterable thành nhiều cột."""
    if colname in df.columns:
        expanded = df[colname].apply(lambda x: x if isinstance(x, dict) else {}).apply(pd.Series)
        expanded.columns = [f"{colname}_{c}" for c in expanded.columns]
        df = pd.concat([df.drop(columns=[colname]), expanded], axis=1)
    return df


def safe_value(v):
    """Đảm bảo giá trị hợp lệ khi upload lên Elasticsearch."""
    if isinstance(v, (dict, list, set, tuple)):
        return str(v)
    return v


def dataframe_to_actions(df, index_name):
    """Chuyển DataFrame thành list actions để upload Elasticsearch."""
    actions = []
    print(f"📊 Chuẩn bị upload {len(df)} dòng, {len(df.columns)} cột...")
    for i, row in df.iterrows():
        source = {col: safe_value(row[col]) for col in df.columns}
        actions.append({"_index": index_name, "_id": str(i), "_source": source})
    return actions


# ====== IMPORT CÁC HÀM TIỆN ÍCH ======
from price_handle_utils import compute_final_price
from brand_utils import infer_brand
from os_utils import process_os
from ram_utils import process_ram
from rom_utils import process_rom
from battery_utils import process_battery
from camera_utils import process_camera
from chipset_utils import process_chipset
from gpu_utils import process_gpu
from display_size_utils import process_display
from screen_utils import process_screen
from sensor_utils import process_sensor
from nfc_utils import process_nfc_column
from jack_support_utils import process_jack_support
from numeric_utils import clean_numeric_column
from normalize import normalize_for_saving


# ====== XỬ LÝ DỮ LIỆU ======
def process_data(df):
    print("🧹 Đang làm sạch và xử lý dữ liệu...")

    # ===== Bung dữ liệu từ các cột dictionary (general, filterable)
    def expand_nested_columns(df, col_name):
        if col_name in df.columns:
            expanded = df[col_name].apply(
                lambda x: x if isinstance(x, dict) else {}
            ).apply(pd.Series)
            expanded = expanded.add_prefix(f"{col_name}_")
            df = pd.concat([df, expanded], axis=1)
        return df

    df = expand_nested_columns(df, "general")
    df = expand_nested_columns(df, "filterable")

    # ===== Đảm bảo các cột quan trọng tồn tại
    essential_cols = [
        "memory_internal", "ram", "rom", "rom_preprocessed", "storage",
        "battery", "camera", "camera_primary", "camera_secondary",
        "os", "chipset", "gpu", "display", "display_size", "screen",
        "sensor", "nfc", "jack", "jack_support", "price", "final_price",
        "screen_max", "watt", "weight", "dimensions", "color"
    ]

    missing_cols = [c for c in essential_cols if c not in df.columns]
    if missing_cols:
        print(f"⚠️ Thiếu {len(missing_cols)} cột: {missing_cols}")
    for col in missing_cols:
        df[col] = None

    # ===== Bước 1: giá & brand
    df["final_price"] = df.apply(compute_final_price, axis=1)
    df["price"] = df["final_price"]
    df["manufacturer"] = df.apply(infer_brand, axis=1)

    # ===== Bước 2: hệ điều hành
    df = process_os(df)
    # Xử lý RAM, ROM, pin, camera,...
    df = process_ram(df)
    df = process_rom(df)
    df = process_battery(df)
    df = process_camera(df)
    df = process_chipset(df)
    df = process_gpu(df)
    df = process_display(df)
    df = process_screen(df)
    df = process_sensor(df)
    df = process_nfc_column(df)
    df = process_jack_support(df)

    # Làm sạch số liệu
    df = clean_numeric_column(df, ["ram", "storage", "battery", "watt", "price"])

    # Chuẩn hóa toàn bộ DataFrame
    df = normalize_for_saving(df)

    print(f"✅ Dữ liệu sau xử lý có {len(df.columns)} cột.")
    print(f"🔢 Cột mẫu: {df.columns[:15].tolist()}")
    return df


# ====== UPLOAD LÊN ELASTICSEARCH ======
def upload_to_elasticsearch(df, index_name):
    print(f"🚀 Đang upload dữ liệu lên Elasticsearch index '{index_name}'...")

    # Ép kiểu dữ liệu an toàn
    df = df.replace({pd.NA: None}).fillna("").astype(str)

    # Chuyển DataFrame thành danh sách hành động
    actions = dataframe_to_actions(df, index_name)

    print(f"📊 Chuẩn bị upload {len(actions)} bản ghi...")

    success, errors = helpers.bulk(
        es,
        actions,
        raise_on_error=False,
        stats_only=False
    )

    print(f"✅ Upload thành công {success} bản ghi.")
    if errors:
        print(f"⚠️ Có {len(errors)} lỗi upload.")
        print("🔍 Một vài lỗi mẫu:")
        print(json.dumps(errors[:3], indent=2, ensure_ascii=False))

