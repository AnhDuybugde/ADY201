import pandas as pd

def compute_final_price(row):
    """
    Tính giá cuối cùng cho mỗi sản phẩm.
    Ưu tiên special_price nếu có, ngược lại dùng price.
    """
    try:
        price = pd.to_numeric(row.get("price", 0), errors="coerce")
        special = pd.to_numeric(row.get("special_price", 0), errors="coerce")

        if pd.notna(special) and special > 0:
            return special
        elif pd.notna(price) and price > 0:
            return price
        else:
            return 0
    except Exception:
        return 0
