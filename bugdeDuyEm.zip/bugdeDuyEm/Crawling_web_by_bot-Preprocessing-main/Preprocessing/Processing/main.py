import pandas as pd
from elasticsearch import Elasticsearch, helpers
from elasticsearch.helpers import scan

# ====== Kết nối Elasticsearch ======
es = Elasticsearch(
    "https://e72eb8c5112142169a3526c1c5f70827.us-central1.gcp.cloud.es.io:443",
    api_key="VUFFVlI1b0JTdWlYUENIT3FSRG86bUN3REh4cHY2bWdDWHpaMUpEOGdiQQ=="
)

RAW_INDEX = "rawdata_phones"
PROCESSED_INDEX = "processed_phones"


# ====== Lấy dữ liệu từ Elasticsearch ======
def fetch_from_elasticsearch(index_name):
    print(f"📥 Đang tải dữ liệu từ Elasticsearch index '{index_name}'...")
    results = []
    ids = []
    for doc in scan(es, index=index_name):
        results.append(doc["_source"])
        ids.append(doc["_id"])  # Lấy id từ Elasticsearch
    df = pd.DataFrame(results)
    df["product_id"] = ids  # Thêm cột product_id
    print(f"✅ Đã lấy {len(df)} bản ghi.")
    return df



# ====== CÁC HÀM XỬ LÝ (copy từ code SQL gốc, chỉ chỉnh lại chút) ======
from price_handle_utils import compute_final_price
from brand_utils import infer_brand
from os_utils import process_os
from ram_utils import process_ram
from rom_utils import process_rom
from battery_utils import process_battery
from camera_utils import process_camera
from chipset_utils import process_chipset
from gpu_utils import process_gpu
from display_size_utils import process_display
from screen_utils import process_screen
from sensor_utils import process_sensor
from nfc_utils import process_nfc_column
from jack_support_utils import process_jack_support
from numeric_utils import clean_numeric_column
from normalize import normalize_for_saving


# ====== Làm sạch & Chuẩn hóa ======
def process_data(df):
    print("🧹 Đang làm sạch và xử lý dữ liệu...")

    # Bước 1: xử lý giá
    df["final_price"] = df.apply(compute_final_price, axis=1)
    # ✅ Thêm dòng này để có cột price
    df["price"] = df["final_price"]
    # Bước 2: chuẩn hóa brand
    df["manufacturer"] = df.apply(infer_brand, axis=1)

    print("📋 Các cột hiện có trong DataFrame:")
    print(df.columns.tolist())

    # 🧩 Thêm bước: trích xuất hệ điều hành từ general / filterable
    def extract_os(row):
        general = row.get("general", {})
        if isinstance(general, dict):
            for key, value in general.items():
                if "hệ điều hành" in key.lower():
                    return value
        filterable = row.get("filterable", {})
        if isinstance(filterable, dict):
            for key, value in filterable.items():
                if "hệ điều hành" in key.lower():
                    return value
        return None

    # Tạo cột os
    df["os"] = df.apply(extract_os, axis=1)
    print("🧠 Đã tạo cột 'os' mới cho DataFrame!")

    # Bước 3: xử lý OS
    df = process_os(df)

    # =========================
    # Chuẩn bị cột memory_internal
    # =========================
    if "memory_internal" not in df.columns:
        print("🧠 Đang tách 'memory_internal' từ cột general...")
        if "general" in df.columns:
            df["memory_internal"] = df["general"].apply(
                lambda x: x.get("memory_internal") if isinstance(x, dict) else None
            )
        elif "filterable" in df.columns:
            df["memory_internal"] = df["filterable"].apply(
                lambda x: x.get("memory_internal") if isinstance(x, dict) else None
            )
        else:
            df["memory_internal"] = None

    # =========================
    # Chuẩn bị cột rom_preprocessed
    # =========================
    if "rom_preprocessed" not in df.columns:
        print("🧠 Đang tách 'rom_preprocessed' từ cột general...")
        def extract_rom(x):
            if isinstance(x, dict):
                for k, v in x.items():
                    if "rom" in k.lower():
                        return v
            return None

        if "general" in df.columns:
            df["rom_preprocessed"] = df["general"].apply(extract_rom)
        elif "filterable" in df.columns:
            df["rom_preprocessed"] = df["filterable"].apply(extract_rom)
        else:
            df["rom_preprocessed"] = None

    print("✅ Các cột hiện có sau khi tách ROM:", df.columns.tolist())
    print("🔍 Mẫu rom_preprocessed:", df["rom_preprocessed"].head())
    if "battery" not in df.columns:
        print("🧠 Đang tách 'battery' từ cột general/filterable...")
        def extract_battery(x):
            if isinstance(x, dict):
                for k, v in x.items():
                    if "pin" in k.lower() or "battery" in k.lower():
                        return v
            return None

        if "general" in df.columns:
            df["battery"] = df["general"].apply(extract_battery)
        elif "filterable" in df.columns:
            df["battery"] = df["filterable"].apply(extract_battery)
        else:
            df["battery"] = None
    # =========================
# Chuẩn bị cột camera_primary & camera_secondary
# =========================
    for cam_col, keywords in [("camera_primary", ["camera chính", "camera primary"]),
                            ("camera_secondary", ["camera phụ", "camera secondary"])]:
        if cam_col not in df.columns:
            print(f"🧠 Đang tách '{cam_col}' từ cột general/filterable...")
            def extract_camera(x):
                if isinstance(x, dict):
                    for k, v in x.items():
                        for kw in keywords:
                            if kw in k.lower():
                                return v
                return None

            if "general" in df.columns:
                df[cam_col] = df["general"].apply(extract_camera)
            elif "filterable" in df.columns:
                df[cam_col] = df["filterable"].apply(extract_camera)
            else:
                df[cam_col] = None
    # =========================
# Chuẩn bị cột chipset
# =========================
    if "chipset" not in df.columns:
        print("🧠 Đang tách 'chipset' từ cột general/filterable...")
        def extract_chipset(x):
            if isinstance(x, dict):
                for k, v in x.items():
                    if "chipset" in k.lower() or "chip set" in k.lower():
                        return v
            return None

        if "general" in df.columns:
            df["chipset"] = df["general"].apply(extract_chipset)
        elif "filterable" in df.columns:
            df["chipset"] = df["filterable"].apply(extract_chipset)
        else:
            df["chipset"] = None
    # =========================
# Chuẩn bị cột gpu/gpu_name
# =========================
    if "gpu" not in df.columns:
        print("🧠 Đang tách 'gpu' từ cột general/filterable...")
        def extract_gpu(x):
            if isinstance(x, dict):
                for k, v in x.items():
                    if "gpu" in k.lower() or "gpu_name" in k.lower():
                        return v
            return None

        if "general" in df.columns:
            df["gpu"] = df["general"].apply(extract_gpu)
        elif "filterable" in df.columns:
            df["gpu"] = df["filterable"].apply(extract_gpu)
        else:
            df["gpu"] = None
    # =========================
# Chuẩn bị cột display_size/screen_max
# =========================
    if "display_size" not in df.columns:
        print("🧠 Đang tách 'display_size' từ cột general/filterable...")
        def extract_display_size(x):
            if isinstance(x, dict):
                for k, v in x.items():
                    if "display_size" in k.lower() or "screen_max" in k.lower():
                        return v
            return None

        if "general" in df.columns:
            df["display_size"] = df["general"].apply(extract_display_size)
        elif "filterable" in df.columns:
            df["display_size"] = df["filterable"].apply(extract_display_size)
        else:
            df["display_size"] = None
# =========================
# Chuẩn bị cột screen/refresh_rate
# =========================
    if "screen" not in df.columns:
        print("🧠 Đang tách 'screen' từ cột general/filterable...")
        def extract_screen(x):
            if isinstance(x, dict):
                for k, v in x.items():
                    if "screen" in k.lower() or "refresh_rate" in k.lower():
                        return v
            return None

        if "general" in df.columns:
            df["screen"] = df["general"].apply(extract_screen)
        elif "filterable" in df.columns:
            df["screen"] = df["filterable"].apply(extract_screen)
        else:
            df["screen"] = None
# =========================
# Chuẩn bị cột screen/refresh_rate
# =========================
    if "screen" not in df.columns:
        print("🧠 Đang tách 'screen' từ cột general/filterable...")
        def extract_screen(x):
            if isinstance(x, dict):
                for k, v in x.items():
                    if "screen" in k.lower() or "refresh_rate" in k.lower():
                        return v
            return None

        if "general" in df.columns:
            df["screen"] = df["general"].apply(extract_screen)
        elif "filterable" in df.columns:
            df["screen"] = df["filterable"].apply(extract_screen)
        else:
            df["screen"] = None
# =========================
# Chuẩn bị cột sensor/mobile_cam_bien
# =========================
    if "sensor" not in df.columns:
        print("🧠 Đang tách 'sensor' từ cột general/filterable...")
        def extract_sensor(x):
            if isinstance(x, dict):
                for k, v in x.items():
                    if "sensor" in k.lower() or "mobile_cam_bien" in k.lower():
                        return v
            return None

        if "general" in df.columns:
            df["sensor"] = df["general"].apply(extract_sensor)
        elif "filterable" in df.columns:
            df["sensor"] = df["filterable"].apply(extract_sensor)
        else:
            df["sensor"] = None
# =========================
# Chuẩn bị cột nfc/mobile_nfc
# =========================
    if "nfc" not in df.columns:
        print("🧠 Đang tách 'nfc' từ cột general/filterable...")
        def extract_nfc(x):
            if isinstance(x, dict):
                for k, v in x.items():
                    if "nfc" in k.lower() or "mobile_nfc" in k.lower():
                        return v
            return None

        if "general" in df.columns:
            df["nfc"] = df["general"].apply(extract_nfc)
        elif "filterable" in df.columns:
            df["nfc"] = df["filterable"].apply(extract_nfc)
        else:
            df["nfc"] = None
# =========================
# Chuẩn bị cột jack_support
# =========================
    if "jack_support" not in df.columns:
        print("🧠 Đang tách 'jack_support' từ cột general/filterable...")
        def extract_jack_support(x):
            if isinstance(x, dict):
                for k, v in x.items():
                    if "jack" in k.lower() or "jack_support" in k.lower():
                        return v
            return None

        if "general" in df.columns:
            df["jack_support"] = df["general"].apply(extract_jack_support)
        elif "filterable" in df.columns:
            df["jack_support"] = df["filterable"].apply(extract_jack_support)
        else:
            df["jack_support"] = None

    # =========================
    # Sau đó mới gọi các hàm xử lý
    # =========================
    df = process_ram(df)
    df = process_rom(df)
    df = process_battery(df)
    df = process_camera(df)

    df = process_chipset(df)
    df = process_gpu(df)
    df = process_display(df)
    df = process_screen(df)
    df = process_sensor(df)
    df = process_nfc_column(df)
    df = process_jack_support(df)

# ----------------------------
# CHUẨN HÓA DỮ LIỆU TRƯỚC KHI LƯU
# ----------------------------
# Chuẩn hóa các cột numeric
df_track = clean_numeric_column(df_track, ["ram", "storage", "battery", "watt", "price"])

# Chuẩn hóa toàn bộ DataFrame
df_saving = normalize_for_saving(df_track)

# Đảm bảo có đầy đủ các cột quan trọng (tránh mất field khi đẩy lên Elasticsearch)
expected_columns = [
    "product_id", "name", "brand", "model", "price", "ram", "storage",
    "battery", "watt", "camera", "chip", "screen", "os", "release_date",
    "weight", "dimensions", "color", "sensor"
]
for col in expected_columns:
    if col not in df_saving.columns:
        df_saving[col] = None

print(f"✅ Tổng dòng trong df_saving: {len(df_saving)}")
print(f"🔢 Số product_id duy nhất: {df_saving['product_id'].nunique()}")

# ----------------------------
# GHI LÊN BẢNG SQL
# ----------------------------
try:
    print("💾 Đang ghi dữ liệu vào bảng SAVING...")
    upsert_saving(cursor, df_saving)
    conn.commit()
    print("✅ Ghi thành công lên SQL!")

    # ----------------------------
    # CẬP NHẬT processed FLAG
    # ----------------------------
    print("🔄 Đang cập nhật processed = 1 cho các bản ghi chưa xử lý...")
    cursor.execute(f"""
        UPDATE {TRACK_TABLE}
        SET processed = 1
        WHERE processed = 0 OR processed IS NULL
    """)
    conn.commit()
    print("✅ Đã cập nhật processed = 1 cho toàn bộ bản ghi chưa xử lý.")

except Exception as e:
    conn.rollback()
    print("❌ Lỗi trong quá trình xử lý:", e)

finally:
    cursor.close()
    conn.close()
    print("🔒 Kết nối cơ sở dữ liệu đã được đóng.")
